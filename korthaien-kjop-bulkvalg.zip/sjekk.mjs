#!/usr/bin/env node
// Sjekker at alle filene fra alle pakkene faktisk ligger inne, og at de er
// den versjonen som gjelder nå. Kjøres fra repo-rota:  node sjekk.mjs
import { readFileSync, existsSync } from "node:fs";
import { createHash } from "node:crypto";

const FASIT = {
  "korthaien-kjop/admin/package-lock.json": "8477b515d76c6962",
  "korthaien-kjop/admin/package.json": "853e81b5c4d60163",
  "korthaien-kjop/admin/src/App.jsx": "48458921d74fcb9d",
  "korthaien-kjop/admin/src/api.js": "faf6e4050df0f3f5",
  "korthaien-kjop/admin/src/views/Innstillinger.jsx": "84a1bd996a6af2de",
  "korthaien-kjop/admin/src/views/Kort.jsx": "9374dfefd6b684fa",
  "korthaien-kjop/admin/src/views/Ordrer.jsx": "0da5a017d7c6caf7",
  "korthaien-kjop/kunde/index.html": "91a00169eb01b9aa",
  "korthaien-kjop/kunde/src/App.jsx": "038a2eeb12863f6b",
  "korthaien-kjop/kunde/src/api.js": "cc8526d14a7ef71f",
  "korthaien-kjop/kunde/src/styles.css": "68f42843731d3a47",
  "korthaien-kjop/kunde/src/views/Bulk.jsx": "6052e53ab942c285",
  "korthaien-kjop/kunde/src/views/Kasse.jsx": "5d0882391c462726",
  "korthaien-kjop/kunde/src/views/Oppslag.jsx": "da59e44011fc6385",
  "korthaien-kjop/kunde/src/views/Sok.jsx": "2827a5bd94219928",
  "korthaien-kjop/kunde/src/views/Vilkar.jsx": "ef224403b533d593",
  "korthaien-kjop/package-lock.json": "f356b393925801ad",
  "korthaien-kjop/package.json": "296480452363f690",
  "korthaien-kjop/render.yaml": "11aaccee637151a2",
  "korthaien-kjop/src/auth.ts": "185b5d7b04daae95",
  "korthaien-kjop/src/bulk.ts": "d1877086e573db2a",
  "korthaien-kjop/src/catalog.ts": "6df611019d2219b6",
  "korthaien-kjop/src/cli.ts": "18b88728496bf9bb",
  "korthaien-kjop/src/db.ts": "f3c6140ed72b23f9",
  "korthaien-kjop/src/epost.ts": "9a244dcf92d8e0a4",
  "korthaien-kjop/src/hvorfor.ts": "71b5c3de84fb1163",
  "korthaien-kjop/src/orders.ts": "badcfac6ccd06fbb",
  "korthaien-kjop/src/pricing.ts": "7940cf4af6637b8a",
  "korthaien-kjop/src/schema.sql": "11c6aff8650e70ce",
  "korthaien-kjop/src/server.ts": "8e65775ac6129532",
  "korthaien-kjop/src/totp.ts": "3400295d7f9bb8ef",
  "korthaien-kjop/test/bulkformat.test.mjs": "c7fca2397dd219c6",
  "korthaien-kjop/test/endringslogg.test.mjs": "a40967ebc06193bd",
  "korthaien-kjop/test/epost.test.mjs": "ff1052fbfce09926",
  "korthaien-kjop/test/kjerne.test.mjs": "0dcb95cc5387b8dd",
  "korthaien-kjop/test/kodelekkasje.test.mjs": "db0875f5f90d46d0",
  "korthaien-kjop/test/manuellpris.test.mjs": "e2a774ce2da2419e",
  "korthaien-kjop/test/oppgjor.test.mjs": "b45b20c42a418cd4",
  "korthaien-kjop/test/ore.test.mjs": "4b184edd6be07a63",
  "korthaien-kjop/test/settandel.test.mjs": "504d47b1ab72018d",
  "korthaien-kjop/test/settihalen.test.mjs": "51eec2e1c5560696",
  "korthaien-kjop/test/totp.test.mjs": "2345d68cc148975b"
};

let mangler = 0, feil = 0, ok = 0;
for (const [sti, sum] of Object.entries(FASIT)) {
  if (!existsSync(sti)) {
    console.log("MANGLER  " + sti);
    mangler++;
    continue;
  }
  const nå = createHash("sha256").update(readFileSync(sti)).digest("hex").slice(0, 16);
  if (nå === sum) ok++;
  else {
    console.log("UTDATERT " + sti);
    feil++;
  }
}

console.log(`\n${ok} av ${Object.keys(FASIT).length} filer er riktige.`);
if (mangler) console.log(`${mangler} mangler helt.`);
if (feil) console.log(`${feil} er en annen versjon enn den siste.`);
if (!mangler && !feil) console.log("Alle pakkene er kjørt. Ingenting mangler.");
