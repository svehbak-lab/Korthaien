#!/usr/bin/env node
// Legger filene i «filer/» inn i repoet. Kjøres fra repo-rota.
//   node oppdater.mjs          legger inn, tar .bak av alt som endres
//   node oppdater.mjs --angre  ruller tilbake fra .bak
//
// Trygg å kjøre flere ganger: filer som allerede er like røres ikke, og
// .bak lages bare første gang en fil endres.

import { readdirSync, statSync, readFileSync, writeFileSync, mkdirSync, existsSync, copyFileSync, unlinkSync } from "node:fs";
import { join, dirname, relative } from "node:path";

const ROT = process.cwd();
const KILDE = join(ROT, "filer");
const angre = process.argv.includes("--angre");

console.log("  Korthaien Kjøp — legg til alle, og bytt utgave");
console.log("  " + ROT);

function alleFiler(dir) {
  const ut = [];
  for (const navn of readdirSync(dir)) {
    const p = join(dir, navn);
    if (statSync(p).isDirectory()) ut.push(...alleFiler(p));
    else ut.push(p);
  }
  return ut;
}

if (angre) {
  let n = 0;
  for (const kilde of alleFiler(KILDE)) {
    const mål = join(ROT, relative(KILDE, kilde));
    const bak = mål + ".bak";
    if (existsSync(bak)) {
      copyFileSync(bak, mål);
      unlinkSync(bak);
      console.log("↩ " + relative(ROT, mål));
      n++;
    }
  }
  console.log(`✓ Rullet tilbake ${n} ${n === 1 ? "fil" : "filer"}.`);
  process.exit(0);
}

if (!existsSync(KILDE)) {
  console.error("✗ Fant ikke mappen «filer». Pakk ut ZIP-en i repo-rota og kjør på nytt.");
  process.exit(1);
}

let nye = 0, endret = 0, uendret = 0;
for (const kilde of alleFiler(KILDE)) {
  const rel = relative(KILDE, kilde);
  const mål = join(ROT, rel);
  const innhold = readFileSync(kilde);

  if (existsSync(mål)) {
    if (readFileSync(mål).equals(innhold)) {
      uendret++;
      continue;
    }
    // .bak lages bare hvis den ikke finnes fra før, så en ny kjøring ikke
    // overskriver originalen med en allerede oppdatert fil.
    if (!existsSync(mål + ".bak")) copyFileSync(mål, mål + ".bak");
    writeFileSync(mål, innhold);
    console.log("✎ " + rel);
    endret++;
  } else {
    mkdirSync(dirname(mål), { recursive: true });
    writeFileSync(mål, innhold);
    console.log("+ " + rel);
    nye++;
  }
}

console.log(`✓ Ferdig — ${nye} nye, ${endret} endret, ${uendret} uendret.`);
console.log(`
  Skal ha endret 5 filer.

  PAKK UT FRA TERMINALEN, ikke med hoeyreklikk i VS Code:
    cd /workspaces/Korthaien && rm -rf filer && unzip -o <zip-fil>

    node sjekk.mjs
    git add -A && git commit -m "Legg til alle, bytt utgave" && git push

  Angre:  node oppdater.mjs --angre`);
